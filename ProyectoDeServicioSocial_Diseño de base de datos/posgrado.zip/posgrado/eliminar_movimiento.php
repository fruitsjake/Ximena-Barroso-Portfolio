<?php
include 'conexion.php';

// Recuperar datos del formulario
$no_CVU = intval($_POST['no_CVU']);

// Construir la consulta SQL para eliminar
$sql = "DELETE FROM movilidad_academica WHERE no_CVU = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $no_CVU);

if ($stmt->execute()) {
    $mensaje = "Movimiento eliminado exitosamente.";
} else {
    $mensaje = "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();

echo "<script>
    alert('$mensaje');
    window.location.href = 'movilidad.php';
</script>";
?>
<?php
include 'conexion.php';

// Recuperar datos del formulario
$no_CVU = intval($_POST['no_CVU']);
$nombre_alumno = htmlspecialchars($_POST['nombre_alumno']);
$lugar_de_movilidad = htmlspecialchars($_POST['lugar_de_movilidad']);
$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = !empty($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;
$investigación = htmlspecialchars($_POST['investigación']);

// Verificar si el no_CVU existe en alumnos_maestria o alumnos_doctorado
$sql_verificar_maestria = "SELECT no_CVU FROM alumnos_maestria WHERE no_CVU = ?";
$sql_verificar_doctorado = "SELECT no_CVU FROM alumnos_doctorado WHERE no_CVU = ?";

$stmt_maestria = $conn->prepare($sql_verificar_maestria);
$stmt_maestria->bind_param("i", $no_CVU);
$stmt_maestria->execute();
$stmt_maestria->store_result();

$stmt_doctorado = $conn->prepare($sql_verificar_doctorado);
$stmt_doctorado->bind_param("i", $no_CVU);
$stmt_doctorado->execute();
$stmt_doctorado->store_result();

if ($stmt_maestria->num_rows > 0 || $stmt_doctorado->num_rows > 0) {
    // Insertar en movilidad_academica (sin restricciones de clave foránea)
    $sql = "INSERT INTO movilidad_academica (no_CVU, nombre_alumno, lugar_de_movilidad, fecha_inicio, fecha_fin, investigación)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $no_CVU, $nombre_alumno, $lugar_de_movilidad, $fecha_inicio, $fecha_fin, $investigación);

    if ($stmt->execute()) {
        $mensaje = "Movimiento agregado exitosamente.";
    } else {
        $mensaje = "Error al insertar: " . $stmt->error;
    }

    $stmt->close();
} else {
    $mensaje = "Error: El no_CVU no existe en alumnos_maestria ni en alumnos_doctorado.";
}

$stmt_maestria->close();
$stmt_doctorado->close();
$conn->close();

echo "<script>
    alert('$mensaje');
    window.location.href = 'movilidad.php';
</script>";
?>
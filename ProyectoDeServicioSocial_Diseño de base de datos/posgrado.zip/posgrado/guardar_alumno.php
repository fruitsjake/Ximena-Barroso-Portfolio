<?php
include 'conexion.php';

// Validar y sanear datos
$programa = $_POST['programa'];
$no_CVU = intval($_POST['no_CVU']);
$nombre = htmlspecialchars($_POST['nombre']);
$fecha_ingreso = $_POST['fecha_ingreso'];
$Fecha_egreso = !empty($_POST['Fecha_egreso']) ? $_POST['Fecha_egreso'] : null;

// Validar formato de fechas
if (!DateTime::createFromFormat('Y-m-d', $fecha_ingreso)) {
    echo "<script>alert('Formato de fecha de ingreso inválido'); window.history.back();</script>";
    exit();
}

if ($Fecha_egreso && !DateTime::createFromFormat('Y-m-d', $Fecha_egreso)) {
    echo "<script>alert('Formato de fecha de egreso inválido'); window.history.back();</script>";
    exit();
}

// Verificar CVU duplicado
$tabla = ($programa == "maestria") ? "alumnos_maestria" : "alumnos_doctorado";
$sql_check = "SELECT no_CVU FROM $tabla WHERE no_CVU = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $no_CVU);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    echo "<script>
        alert('Error: El número CVU $no_CVU ya está registrado');
        window.history.back();
    </script>";
    exit();
}
$stmt_check->close();

// Insertar en BD
$sql = "INSERT INTO $tabla (no_CVU, Nombre, Fecha_ingreso, Fecha_egreso) 
        VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isss", $no_CVU, $nombre, $fecha_ingreso, $Fecha_egreso);

if ($stmt->execute()) {
    $mensaje = "Alumno registrado exitosamente!";
} else {
    $mensaje = "Error al registrar: " . $conn->error;
}

$stmt->close();
$conn->close();

echo "<script>
    alert('$mensaje');
    window.location.href = 'index.php';
</script>";
?>
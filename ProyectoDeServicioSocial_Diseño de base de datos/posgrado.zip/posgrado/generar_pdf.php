<?php
require_once('tcpdf/tcpdf.php');
include 'conexion.php';

// Recoger parámetros del formulario
$programa = $_POST['programa'];
$anio_inicio = intval($_POST['anio_inicio']);
$anio_fin = !empty($_POST['anio_fin']) ? intval($_POST['anio_fin']) : $anio_inicio;

// Determinar tablas a consultar
$tablas = [];
if($programa == 'maestria') {
    $tablas = ['alumnos_maestria'];
} elseif($programa == 'doctorado') {
    $tablas = ['alumnos_doctorado'];
} else {
    $tablas = ['alumnos_maestria', 'alumnos_doctorado'];
}

$datos_combinados = [];
$total_ingresos = 0;
$total_graduados = 0;
$suma_tiempos = 0;

foreach($tablas as $tabla) {
    // Construir consulta
    $sql = "SELECT 
                YEAR(Fecha_ingreso) as generacion,
                COUNT(*) as ingresos,
                SUM(CASE WHEN Fecha_obtencion_grado IS NOT NULL THEN 1 ELSE 0 END) as graduados,
                AVG(DATEDIFF(Fecha_obtencion_grado, Fecha_ingreso)/365.25) as tiempo_promedio
            FROM $tabla
            WHERE YEAR(Fecha_ingreso) BETWEEN ? AND ?
            GROUP BY generacion ORDER BY generacion";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $anio_inicio, $anio_fin);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $generacion = $row['generacion'];
        
        if(!isset($datos_combinados[$generacion])) {
            $datos_combinados[$generacion] = [
                'ingresos' => 0,
                'graduados' => 0,
                'tiempo' => 0.0,
                'contador' => 0
            ];
        }
        
        $datos_combinados[$generacion]['ingresos'] += $row['ingresos'];
        $datos_combinados[$generacion]['graduados'] += $row['graduados'];
        $datos_combinados[$generacion]['tiempo'] += $row['tiempo_promedio'];
        $datos_combinados[$generacion]['contador']++;
    }
}

// Calcular promedios y preparar datos para mostrar
$stats = [];
foreach($datos_combinados as $generacion => $data) {
    $porcentaje = ($data['ingresos'] > 0) ? ($data['graduados'] / $data['ingresos']) * 100 : 0;
    $tiempo_promedio = ($data['contador'] > 0) ? $data['tiempo'] / $data['contador'] : 0;
    
    $stats[] = [
        'generacion' => $generacion,
        'ingresos' => $data['ingresos'],
        'graduados' => $data['graduados'],
        'porcentaje' => $porcentaje,
        'tiempo' => $tiempo_promedio
    ];
    
    // Acumular totales
    $total_ingresos += $data['ingresos'];
    $total_graduados += $data['graduados'];
    $suma_tiempos += $tiempo_promedio;
}

// Calcular totales finales
$total_porcentaje = ($total_ingresos > 0) ? ($total_graduados / $total_ingresos) * 100 : 0;
$total_tiempo = (count($stats) > 0) ? $suma_tiempos / count($stats) : 0;

// Crear nuevo documento PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Configuración del documento
$pdf->SetCreator('Sistema de Gestión de Alumnos');
$pdf->SetAuthor('Tu Nombre');
$pdf->SetTitle('Reporte Estadístico');
$pdf->SetSubject('Estadísticas de Alumnos');
$pdf->SetKeywords('PDF, Estadísticas, Alumnos');

// Configurar márgenes
$pdf->SetMargins(15, 25, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(15);

// Agregar una página
$pdf->AddPage();

// Contenido del PDF
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 15, 'Reporte Estadístico de Alumnos', 0, 1, 'C');
$pdf->Ln(8); // Espacio adicional

// Información del reporte
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(0, 10, 'Programa: ' . ucfirst($programa), 0, 1);
$pdf->Cell(0, 10, 'Período: ' . $anio_inicio . ' - ' . $anio_fin, 0, 1);
$pdf->Ln(12); // Más espacio antes de la tabla

// Crear tabla con estadísticas
$pdf->SetFont('helvetica', 'B', 12);
$pdf->SetFillColor(240, 240, 240); // Color de fondo para encabezados
$pdf->Cell(40, 10, 'Generación', 1, 0, 'C', 1);
$pdf->Cell(30, 10, 'Ingresos', 1, 0, 'C', 1);
$pdf->Cell(30, 10, 'Graduados', 1, 0, 'C', 1);
$pdf->Cell(40, 10, '% Graduados', 1, 0, 'C', 1);
$pdf->Cell(40, 10, 'Tiempo Promedio', 1, 1, 'C', 1);

$pdf->SetFont('helvetica', '', 10);
foreach ($stats as $stat) {
    $pdf->Cell(40, 10, $stat['generacion'], 1, 0, 'C');
    $pdf->Cell(30, 10, $stat['ingresos'], 1, 0, 'C');
    $pdf->Cell(30, 10, $stat['graduados'], 1, 0, 'C');
    $pdf->Cell(40, 10, round($stat['porcentaje'], 2) . '%', 1, 0, 'C');
    $pdf->Cell(40, 10, round($stat['tiempo'], 2) . ' años', 1, 1, 'C');
}

// Fila de totales
$pdf->SetFont('helvetica', 'B', 10);
$pdf->SetFillColor(227, 242, 253); // Color azul claro para fila total
$pdf->Cell(40, 10, 'TOTAL', 1, 0, 'C', 1);
$pdf->Cell(30, 10, $total_ingresos, 1, 0, 'C', 1);
$pdf->Cell(30, 10, $total_graduados, 1, 0, 'C', 1);
$pdf->Cell(40, 10, round($total_porcentaje, 2) . '%', 1, 0, 'C', 1);
$pdf->Cell(40, 10, round($total_tiempo, 2) . ' años', 1, 1, 'C', 1);

// Espacio antes de la gráfica
$pdf->Ln(50); // Espacio significativo entre tabla y gráfica

// Si hay muchos datos, agregar nueva página para la gráfica
if ($pdf->GetY() > 180) {
    $pdf->AddPage();
    $pdf->SetY(30);
}

// Título de la gráfica
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, 'Tiempo Promedio de Graduación', 0, 1, 'C');
$pdf->Ln(8); // Espacio después del título

// Crear gráfico básico con barras
$max_valor = max(array_column($stats, 'tiempo')) * 1.2; // Margen del 20%
$ancho_barra = 160 / max(count($stats), 1); // Evitar división por cero
$x = 25;
$y_start = $pdf->GetY() + 70; // Posición Y inicial para la gráfica

// Eje Y
$pdf->Line(20, $y_start, 20, $y_start - 50);
$pdf->Line(20, $y_start, 190, $y_start);

// Etiquetas eje Y
for ($i = 0; $i <= $max_valor; $i += 0.5) {
    $y = $y_start - ($i / $max_valor * 50);
    $pdf->Line(18, $y, 20, $y);
    $pdf->Text(10, $y - 2, number_format($i, 1));
}

// Dibujar barras
foreach ($stats as $stat) {
    $altura_barra = ($stat['tiempo'] / $max_valor) * 50;
    
    // Barra
    $pdf->SetFillColor(54, 162, 235);
    $pdf->Rect($x, $y_start - $altura_barra, $ancho_barra - 5, $altura_barra, 'F');
    
    // Etiqueta de año
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Text($x + ($ancho_barra/2) - 5, $y_start + 5, $stat['generacion']);
    
    // Etiqueta de valor
    $pdf->SetFont('helvetica', '', 9);
    $pdf->Text($x + ($ancho_barra/2) - 8, $y_start - $altura_barra - 5, round($stat['tiempo'], 2) . ' años');
    
    $x += $ancho_barra;
}

// Salida del PDF
$pdf->Output('reporte_estadisticas.pdf', 'D');

// Cerrar conexión
$conn->close();
?>
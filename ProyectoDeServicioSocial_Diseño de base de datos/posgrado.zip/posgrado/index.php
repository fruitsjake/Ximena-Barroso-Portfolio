<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Alumnos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }        
        h1 {
            text-align: center;
            color: #333;
        }
        header {
            background-color: #007BFF;
            padding: 10px 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .navbar {
            display: flex;
            gap: 20px;
        }
        .navbar a {
            color: #007BFF;
            text-decoration: none;
            font-size: 20px;
            transition: color 0.3s;
            background-color: white;
            padding: 10px;
            border-radius: 10px
        }
        .navbar a:hover {
            color: #f8f9fa;
            background-color:rgb(80, 164, 255);
        }
        .menu {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        .menu button {
            padding: 10px 20px;
            border: none;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .menu button:hover {
            background-color: #0056b3;
        }
        .seccion-acciones {
            display: none;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .seccion-acciones.activa {
            display: block;
        }
        .seccion-fija {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .contenedor {
            width: 100%;
            
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        label {
            color: #666;
            font-size: 0.9em;
        }
        input, select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f8f8;
            color: #333;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        #graficaTiempoPromedio {
            max-width: 100%; 
            height: 400px;   
            margin: 20px auto;
        }
        .total-row {
            background-color: #e3f2fd;
            font-weight: bold;
        }
        .total-row td {
            padding: 12px;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .campos-adicionales {
            margin: 15px 0;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .grupo-campos {
            margin: 10px 0;
        }
        .grupo-campos label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }
        .grupo-campos input {
            margin: 5px;
            padding: 8px;
            width: 48%;
        }
        .grupo-campos-tabla {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: help;
            position: relative;
        }
        .grupo-campos-tabla:hover {
            white-space: normal;
            overflow: visible;
            z-index: 1000;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .lista-vertical {
            list-style-type: none;
            padding-left: 0;
            margin: 5px 0;
        }
        .lista-vertical li {
            margin: 3px 0;
        }
        .formulario-pdf {
            background-color: #e8f4f8;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .formulario-pdf h2 {
            margin-top: 0;
            color: #0056b3;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<header>
    <h1>Gestión de Alumnos</h1>
    <nav class="navbar">
        <a href="index.php">Gestión de Alumnos</a>
        <a href="movilidad.php">Movilidad Académica</a>
    </nav>
</header>

<h1>Gestión de Alumnos</h1>

<!-- Menú de Pestañas -->
<div class="menu">
    <button onclick="mostrarSeccion('agregar')">Agregar Alumno</button>
    <button onclick="mostrarSeccion('actualizar')">Actualizar Alumno</button>
    <button onclick="mostrarSeccion('eliminar')">Eliminar Alumno</button>
</div>

<div class="contenedor">
    <!-- Sección de Agregar Alumno -->
    <div id="agregar" class="seccion-acciones activa">
        <h2>Agregar Alumno</h2>
        <form action="guardar_alumno.php" method="post">
            <label for="programa">Programa:</label>
            <select id="programa" name="programa" required>
                <option value="maestria">Maestría</option>
                <option value="doctorado">Doctorado</option>
            </select>
            <label for="no_CVU">No. CVU:</label>
            <input type="number" id="no_CVU" name="no_CVU" required>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" maxlength="50" required>
            <label for="fecha_ingreso">Fecha de Ingreso:</label>
            <input type="date" id="fecha_ingreso" name="fecha_ingreso" required>
            <label for="Fecha_egreso">Fecha de Egreso:</label>
            <input type="date" id="Fecha_egreso" name="Fecha_egreso">
            <input type="submit" value="Agregar Alumno">
        </form>
    </div>

    <!-- Sección de Actualizar Alumno -->
    <div id="actualizar" class="seccion-acciones">
        <h2>Actualizar Alumno</h2>
        <form action="actualizar_alumno.php" method="post" enctype="multipart/form-data">
        <!-- Campos comunes -->
        <label for="programa_actualizar">Programa:</label>
        <select id="programa_actualizar" name="programa" required onchange="mostrarCamposAdicionales()">
            <option value="maestria">Maestría</option>
            <option value="doctorado">Doctorado</option>
        </select>

        <label for="no_CVU_actualizar">No. CVU:</label>
        <input type="number" id="no_CVU_actualizar" name="no_CVU" required>

        <!-- Campos comunes a ambos programas -->
        <div class="campos-adicionales">
            <div class="grupo-campos">
                <label>Directores de Tesis:</label>
                <input type="text" name="primer_director_tesis" placeholder="Primer director">
                <input type="text" name="segundo_director_tesis" placeholder="Segundo director">
            </div>
        </div>

        <!-- Lectores críticos -->
        <div class="campos-adicionales">
            <div class="grupo-campos">
                <label>Lectores Críticos:</label>
                <input type="text" name="primer_lector_critico" placeholder="Primer lector">
                <input type="text" name="segundo_lector_critico" placeholder="Segundo lector">
                
                <!-- Campos extra para Doctorado -->
                <div id="lectores-extra-doctorado" style="display: none;">
                    <input type="text" name="tercer_lector_critico" placeholder="Tercer lector">
                    <input type="text" name="cuarto_lector_critico" placeholder="Cuarto lector">
                </div>
            </div>
        </div>

        <!-- Jurado (común a ambos) -->
        <div class="campos-adicionales">
            <div class="grupo-campos">
                <label>Jurado:</label>
                <input type="text" name="presidente" placeholder="Presidente">
                <input type="text" name="secretario" placeholder="Secretario">
                <input type="text" name="primer_vocal" placeholder="Primer vocal">
                <input type="text" name="segundo_vocal" placeholder="Segundo vocal">
                <input type="text" name="tercer_vocal" placeholder="Tercer vocal">
            </div>
        </div>

        <!-- Resto de campos -->
        <label for="Fecha_obtencion_grado">Fecha de Obtención de Grado:</label>
        <input type="date" id="Fecha_obtencion_grado" name="Fecha_obtencion_grado">
        
        <label for="fecha_baja">Fecha de Baja:</label>
        <input type="date" id="fecha_baja" name="fecha_baja">
        
        <label for="documento_baja">Documento de Baja:</label>
        <input type="file" id="documento_baja" name="documento_baja">
        
        <input type="submit" value="Actualizar Alumno">
    </form>
    </div>

    <!-- Sección de Eliminar Alumno -->
    <div id="eliminar" class="seccion-acciones">
        <h2>Eliminar Alumno</h2>
        <form action="eliminar_alumno.php" method="post">
            <label for="programa_eliminar">Programa:</label>
            <select id="programa_eliminar" name="programa" required>
                <option value="maestria">Maestría</option>
                <option value="doctorado">Doctorado</option>
            </select>
            <label for="no_CVU_eliminar">No. CVU:</label>
            <input type="number" id="no_CVU_eliminar" name="no_CVU" required>
            <input type="submit" value="Eliminar Alumno">
        </form>
    </div>

    <!-- Sección de Mostrar Alumnos (Fija) -->
    <div class="seccion-fija">
        <h2>Mostrar Alumnos</h2>
        <form action="" method="get">
            <label for="programa_mostrar">Programa:</label>
            <select id="programa_mostrar" name="programa" required>
                <option value="maestria">Maestría</option>
                <option value="doctorado">Doctorado</option>
            </select>
            <label for="no_CVU_mostrar">No. CVU:</label>
            <input type="number" id="no_CVU_mostrar" name="no_CVU">
            <label for="nombre_mostrar">Nombre:</label>
            <input type="text" id="nombre_mostrar" name="nombre">
            <label for="fecha_ingreso_mostrar">Fecha de Ingreso:</label>
            <input type="date" id="fecha_ingreso_mostrar" name="fecha_ingreso">
            <label for="fecha_obtencion_grado_mostrar">Fecha de Obtención de Grado:</label>
            <input type="date" id="fecha_obtencion_grado_mostrar" name="Fecha_obtencion_grado">
            <label for="fecha_baja_mostrar">Fecha de Baja:</label>
            <input type="date" id="fecha_baja_mostrar" name="fecha_baja">
            <label for="en_tiempo_mostrar">En Tiempo:</label>
            <input type="number" id="en_tiempo_mostrar" name="en_tiempo" step="0.01">
            <label for="fuera_tiempo_mostrar">Fuera de Tiempo:</label>
            <input type="number" id="fuera_tiempo_mostrar" name="fuera_tiempo" step="0.01">
            <input type="submit" value="Filtrar Alumnos">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["programa"])) {
            include 'conexion.php';

            $programa = $_GET["programa"];
            $tabla = ($programa == "maestria") ? "alumnos_maestria" : "alumnos_doctorado";

            // Construir consulta según la tabla
            if($programa == "maestria") {
                $sql = "SELECT *,
                        primer_director_tesis,
                        segundo_director_tesis,
                        presidente,
                        secretario,
                        primer_vocal,
                        segundo_vocal,
                        tercer_vocal
                        FROM $tabla WHERE 1=1";
            } else {
                $sql = "SELECT *,
                        primer_director_tesis,
                        segundo_director_tesis,
                        primer_lector_critico,
                        segundo_lector_critico,
                        tercer_lector_critico,
                        cuarto_lector_critico,
                        presidente,
                        secretario,
                        primer_vocal,
                        segundo_vocal,
                        tercer_vocal
                        FROM $tabla WHERE 1=1";
            }

            // Filtrar por No. CVU
            if (!empty($_GET["no_CVU"])) {
                $no_CVU = $_GET["no_CVU"];
                $sql .= " AND No_CVU = $no_CVU";
            }

            // Filtrar por Nombre
            if (!empty($_GET["nombre"])) {
                $nombre = $_GET["nombre"];
                $sql .= " AND Nombre LIKE '%$nombre%'";
            }

            // Filtrar por Fecha de Ingreso
            if (!empty($_GET["fecha_ingreso"])) {
                $fecha_ingreso = $_GET["fecha_ingreso"];
                $sql .= " AND Fecha_ingreso = '$fecha_ingreso'";
            }

            // Filtrar por Fecha de Obtención de Grado
            if (!empty($_GET["Fecha_obtencion_grado"])) {
                $Fecha_obtencion_grado = $_GET["Fecha_obtencion_grado"];
                $sql .= " AND Fecha_obtencion_grado = '$Fecha_obtencion_grado'";
            }

            // Filtrar por Fecha de Baja
            if (!empty($_GET["fecha_baja"])) {
                $fecha_baja = $_GET["fecha_baja"];
                $sql .= " AND Fecha_baja = '$fecha_baja'";
            }

            // Filtrar por En Tiempo
            if (!empty($_GET["en_tiempo"])) {
                $en_tiempo = $_GET["en_tiempo"];
                $sql .= " AND En_tiempo = $en_tiempo";
            }

            // Filtrar por Fuera de Tiempo
            if (!empty($_GET["fuera_tiempo"])) {
                $fuera_tiempo = $_GET["fuera_tiempo"];
                $sql .= " AND Fuera_tiempo = $fuera_tiempo";
            }

            // Ejecutar la consulta
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Funciones de formato
                function formatDirectores($row) {
                    $output = '';
                    if(!empty($row['primer_director_tesis'])) {
                        $output .= "- " . htmlspecialchars($row['primer_director_tesis']) . "<br>";
                    }
                    if(!empty($row['segundo_director_tesis'])) {
                        $output .= "- " . htmlspecialchars($row['segundo_director_tesis']) . "<br>";
                    }
                    return $output ?: 'No registrado';
                }

                function formatLectores($row) {
                    $output = '';
                    $lectores = [
                        $row['primer_lector_critico'],
                        $row['segundo_lector_critico'],
                        $row['tercer_lector_critico'] ?? null,
                        $row['cuarto_lector_critico'] ?? null
                    ];
                    
                    foreach(array_filter($lectores) as $lector) {
                        $output .= "- " . htmlspecialchars($lector) . "<br>";
                    }
                    return $output ?: 'No registrado';
                }

                function formatComite($row) {
                    $output = '';
                    
                    if(!empty($row['presidente'])) {
                        $output .= "<strong>Presidente:</strong> " . htmlspecialchars($row['presidente']) . "<br>";
                    }
                    if(!empty($row['secretario'])) {
                        $output .= "<strong>Secretario(a):</strong> " . htmlspecialchars($row['secretario']) . "<br>";
                    }
                    
                    $vocales = [
                        $row['primer_vocal'],
                        $row['segundo_vocal'],
                        $row['tercer_vocal']
                    ];
                    
                    $vocalesList = array_filter($vocales);
                    if(!empty($vocalesList)) {
                        $output .= "<strong>Vocales:</strong><br>";
                        foreach($vocalesList as $vocal) {
                            $output .= "- " . htmlspecialchars($vocal) . "<br>";
                        }
                    }
                    
                    return $output ?: 'No registrado';
                }

                function formatFecha($fecha) {
                    return ($fecha != "0000-00-00" && !empty($fecha)) ? htmlspecialchars($fecha) : "";
                }

                function formatDocumentoBaja($documento) {
                    return (!empty($documento)) ? 
                        "<a href='" . htmlspecialchars($documento) . "' download>Descargar</a>" : 
                        "No disponible";
                }

                echo "<table>
                        <tr>
                            <th>No. CVU</th>
                            <th>Nombre</th>
                            <th>Directores</th>";
                
                if($programa == "doctorado") {
                    echo "<th>Lectores</th>";
                }
                
                echo "<th>Comité</th>
                            <th>Fecha Ingreso</th>
                            <th>Fecha Egreso</th>
                            <th>Fecha Obtención</th>
                            <th>Fecha Baja</th>
                            <th>Documento</th>
                            <th>En Tiempo</th>
                            <th>Fuera Tiempo</th>
                        </tr>";
                
                while($row = $result->fetch_assoc()) {
                    $directoresTitle = implode(', ', array_filter([
                        $row['primer_director_tesis'],
                        $row['segundo_director_tesis']
                    ], 'strlen'));
                    
                    echo "<tr>
                            <td>" . htmlspecialchars($row["no_CVU"]) . "</td>
                            <td>" . htmlspecialchars($row["Nombre"]) . "</td>
                            <td class='grupo-campos-tabla' title='" . htmlspecialchars($directoresTitle) . "'>" 
                                . formatDirectores($row) . "</td>";
                    
                    if($programa == "doctorado") {
                        $lectoresTitle = implode(', ', array_filter([
                            $row['primer_lector_critico'],
                            $row['segundo_lector_critico'],
                            $row['tercer_lector_critico'],
                            $row['cuarto_lector_critico']
                        ], 'strlen'));
                        
                        echo "<td class='grupo-campos-tabla' title='" . htmlspecialchars($lectoresTitle) . "'>" 
                            . formatLectores($row) . "</td>";
                    }
                    
                    $comiteTitle = implode(', ', array_filter([
                        $row['presidente'],
                        $row['secretario'],
                        $row['primer_vocal'],
                        $row['segundo_vocal'],
                        $row['tercer_vocal']
                    ], 'strlen'));
                    
                    echo "<td class='grupo-campos-tabla' title='" . htmlspecialchars($comiteTitle) . "'>" 
                            . formatComite($row) . "</td>
                            <td>" . htmlspecialchars($row["Fecha_ingreso"]) . "</td>
                            <td>" . htmlspecialchars($row["Fecha_egreso"]) . "</td>
                            <td>" . formatFecha($row["Fecha_obtencion_grado"]) . "</td>
                            <td>" . formatFecha($row["Fecha_baja"]) . "</td>
                            <td>" . formatDocumentoBaja($row["documento_baja"]) . "</td>
                            <td>" . htmlspecialchars($row["En_tiempo"]) . "</td>
                            <td>" . htmlspecialchars($row["Fuera_tiempo"]) . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "No se encontraron alumnos con los criterios especificados.";
            }

            $conn->close();
        }
        ?>
    </div>

    <!-- Sección de Estadísticas por Generación -->
    <div class="seccion-fija">
        <h2>Estadísticas por Generación</h2>
        <form action="" method="get">
            <label for="programa_estadisticas">Programa:</label>
            <select id="programa_estadisticas" name="programa_estadisticas">
                <option value="">Todos</option>
                <option value="maestria">Maestría</option>
                <option value="doctorado">Doctorado</option>
            </select>

            <label for="anio_generacion">Año de Generación:</label>
            <input type="number" id="anio_generacion" name="anio_generacion" min="2000" max="2099">
            
            <input type="submit" value="Generar Estadísticas">
        </form>

        <?php
        include 'conexion.php';
        
        // Obtener parámetros de filtro
        $programa_estadisticas = isset($_GET['programa_estadisticas']) ? $_GET['programa_estadisticas'] : '';
        $anio_generacion = isset($_GET['anio_generacion']) ? intval($_GET['anio_generacion']) : null;

        // Determinar tablas a consultar
        $tablas = [];
        if(empty($programa_estadisticas)) {
            $tablas = ['alumnos_maestria', 'alumnos_doctorado'];
        } else {
            $tablas = [$programa_estadisticas == 'maestria' ? 'alumnos_maestria' : 'alumnos_doctorado'];
        }

        $datos_combinados = [];
        $total_ingresos = 0;
        $total_graduados = 0;
        $suma_tiempos = 0;
        
        foreach($tablas as $tabla) {
            // Construir consulta
            $sql = "SELECT 
                        YEAR(Fecha_ingreso) as generacion,
                        COUNT(*) as ingresos,
                        SUM(CASE WHEN Fecha_obtencion_grado IS NOT NULL THEN 1 ELSE 0 END) as graduados,
                        AVG(DATEDIFF(Fecha_obtencion_grado, Fecha_ingreso)/365.25) as tiempo_promedio
                    FROM $tabla
                    WHERE 1=1";
            
            if($anio_generacion) {
                $sql .= " AND YEAR(Fecha_ingreso) = $anio_generacion";
            }
            $sql .= " GROUP BY generacion ORDER BY generacion";

            $result = $conn->query($sql);
            
            while($row = $result->fetch_assoc()) {
                $generacion = $row['generacion'];
                
                if(!isset($datos_combinados[$generacion])) {
                    $datos_combinados[$generacion] = [
                        'ingresos' => 0,
                        'graduados' => 0,
                        'tiempo' => 0.0,
                        'contador' => 0
                    ];
                }
                
                $datos_combinados[$generacion]['ingresos'] += $row['ingresos'];
                $datos_combinados[$generacion]['graduados'] += $row['graduados'];
                $datos_combinados[$generacion]['tiempo'] += $row['tiempo_promedio'];
                $datos_combinados[$generacion]['contador']++;
            }
        }

        // Calcular promedios y preparar datos para mostrar
        $stats = [];
        foreach($datos_combinados as $generacion => $data) {
            $porcentaje = ($data['ingresos'] > 0) ? ($data['graduados'] / $data['ingresos']) * 100 : 0;
            $tiempo_promedio = ($data['contador'] > 0) ? $data['tiempo'] / $data['contador'] : 0;
            
            $stats[] = [
                'generacion' => $generacion,
                'ingresos' => $data['ingresos'],
                'graduados' => $data['graduados'],
                'porcentaje' => $porcentaje,
                'tiempo' => $tiempo_promedio
            ];
            
            // Acumular totales
            $total_ingresos += $data['ingresos'];
            $total_graduados += $data['graduados'];
            $suma_tiempos += $tiempo_promedio;
        }

        // Calcular totales finales
        $total_porcentaje = ($total_ingresos > 0) ? ($total_graduados / $total_ingresos) * 100 : 0;
        $total_tiempo = (count($stats) > 0) ? $suma_tiempos / count($stats) : 0;
        ?>

        <table>
            <thead>
                <tr>
                    <th>Inicio Generación</th>
                    <th>Ingresos</th>
                    <th>Graduados</th>
                    <th>% Graduados/Ingresos</th>
                    <th>Tiempo Promedio</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($stats as $stat): ?>
                <tr>
                    <td><?= $stat['generacion'] ?></td>
                    <td><?= $stat['ingresos'] ?></td>
                    <td><?= $stat['graduados'] ?></td>
                    <td><?= round($stat['porcentaje'], 2) ?>%</td>
                    <td><?= round($stat['tiempo'], 2) ?> años</td>
                </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td><strong>Total</strong></td>
                    <td><strong><?= $total_ingresos ?></strong></td>
                    <td><strong><?= $total_graduados ?></strong></td>
                    <td><strong><?= round($total_porcentaje, 2) ?>%</strong></td>
                    <td><strong><?= round($total_tiempo, 2) ?> años</strong></td>
                </tr>
            </tbody>
        </table>

        <?php
        // Preparar datos para la gráfica
        $labels = []; // Años (eje X)
        $data = [];   // Promedio de tiempo de graduación (eje Y)

        foreach ($stats as $stat) {
            $labels[] = $stat['generacion'];
            $data[] = $stat['tiempo'];
        }

        // Convertir datos a formato JSON para JavaScript
        $labels_json = json_encode($labels);
        $data_json = json_encode($data);
        ?>
    </div>

    <!-- Gráfica de Tiempo Promedio de Graduación -->
    <div class="seccion-fija">
        <h2>Gráfica de Tiempo Promedio de Graduación</h2>
        <canvas id="graficaTiempoPromedio" width="800" height="400"></canvas>
    </div>

    <!-- Nuevo formulario para generar PDF -->
    <div class="seccion-fija formulario-pdf">
        <h2>Generar Reporte Estadístico en PDF</h2>
        <form action="generar_pdf.php" method="post">
            <label for="programa_pdf">Programa:</label>
            <select id="programa_pdf" name="programa" required>
                <option value="maestria">Maestría</option>
                <option value="doctorado">Doctorado</option>
                <option value="todos">Todos los Programas</option>
            </select>

            <label for="anio_inicio">Año Inicio (Obligatorio):</label>
            <input type="number" id="anio_inicio" name="anio_inicio" min="2000" max="2099" required>

            <label for="anio_fin">Año Fin (Opcional):</label>
            <input type="number" id="anio_fin" name="anio_fin" min="2000" max="2099">

            <input type="submit" value="Generar PDF">
        </form>
    </div>

    <script>
        // Datos para la gráfica
        const labels = <?= $labels_json ?>; // Años
        const data = <?= $data_json ?>;     // Tiempo promedio

        // Configuración de la gráfica
        const config = {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Tiempo Promedio de Graduación (años)',
                    data: data,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)', // Color de las barras
                    borderColor: 'rgba(54, 162, 235, 1)',      // Borde de las barras
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Tiempo Promedio (años)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Año de Generación'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        };

        // Renderizar la gráfica
        const ctx = document.getElementById('graficaTiempoPromedio').getContext('2d');
        new Chart(ctx, config);

        // JavaScript para Mostrar/Ocultar Secciones
        function mostrarSeccion(seccionId) {
            // Ocultar todas las secciones de acciones
            document.querySelectorAll('.seccion-acciones').forEach(seccion => {
                seccion.classList.remove('activa');
            });

            // Mostrar la sección seleccionada
            document.getElementById(seccionId).classList.add('activa');
        }

        // Mostrar campos adicionales según programa
        function mostrarCamposAdicionales() {
            const programa = document.getElementById('programa_actualizar').value;
            const divLectoresExtra = document.getElementById('lectores-extra-doctorado');
            
            // Mostrar campos extra solo para Doctorado
            divLectoresExtra.style.display = programa === 'doctorado' ? 'block' : 'none';
        }
    </script>
</div>
</body>
</html>
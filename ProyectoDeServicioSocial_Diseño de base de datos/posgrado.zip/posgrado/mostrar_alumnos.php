<?php
include 'conexion.php';

// Función para mostrar datos de una tabla en una tabla HTML
function mostrarAlumnos($conn, $tabla) {
    echo "<h2>Alumnos de " . ($tabla == "alumnos_maestria" ? "Maestría" : "Doctorado") . "</h2>";

    // Construir consulta según la tabla
    if($tabla == "alumnos_maestria") {
        $sql = "SELECT *,
                CONCAT_WS(', ', 
                    NULLIF(primer_director_tesis, ''), 
                    NULLIF(segundo_director_tesis, '')
                ) AS directores,
                
                CONCAT_WS(', ', 
                    NULLIF(presidente, ''), 
                    NULLIF(secretario, ''),
                    NULLIF(primer_vocal, ''),
                    NULLIF(segundo_vocal, ''),
                    NULLIF(tercer_vocal, '')
                ) AS comite
                FROM $tabla";
    } else {
        $sql = "SELECT *,
                CONCAT_WS(', ', 
                    NULLIF(primer_director_tesis, ''), 
                    NULLIF(segundo_director_tesis, '')
                ) AS directores,
                
                CONCAT_WS(', ', 
                    NULLIF(primer_lector_critico, ''), 
                    NULLIF(segundo_lector_critico, ''),
                    NULLIF(tercer_lector_critico, ''),
                    NULLIF(cuarto_lector_critico, '')
                ) AS lectores,
                
                CONCAT_WS(', ', 
                    NULLIF(presidente, ''), 
                    NULLIF(secretario, ''),
                    NULLIF(primer_vocal, ''),
                    NULLIF(segundo_vocal, ''),
                    NULLIF(tercer_vocal, '')
                ) AS comite
                FROM $tabla";
    }

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Crear una tabla HTML para mostrar los datos
        echo '<style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    padding: 10px;
                    border: 1px solid #ddd;
                    text-align: left;
                }
                th {
                    background-color: #f8f8f8;
                }
                tr:hover {
                    background-color: #f9f9f9;
                }
                .grupo-campos {
                    max-width: 200px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    cursor: help;
                    position: relative;
                }
                .grupo-campos:hover {
                    white-space: normal;
                    overflow: visible;
                    z-index: 1000;
                    background: white;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                }
              </style>';

        echo '<table>
                <tr>
                    <th>No. CVU</th>
                    <th>Nombre</th>
                    <th>Directores</th>';
        
        // Solo mostrar columna de Lectores para doctorado
        if($tabla == "alumnos_doctorado") {
            echo '<th>Lectores</th>';
        }
        
        echo '<th>Comité</th>
                    <th>Fecha Ingreso</th>
                    <th>Fecha Obtención</th>
                    <th>Fecha Baja</th>
                    <th>En Tiempo</th>
                    <th>Fuera Tiempo</th>
                </tr>';

        // Mostrar cada fila de resultados
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row["No_CVU"]) . "</td>
                    <td>" . htmlspecialchars($row["Nombre"]) . "</td>
                    <td class='grupo-campos' title='".htmlspecialchars($row["directores"])."'>" . 
                        ($row["directores"] ? htmlspecialchars($row["directores"]) : "No aplica") . "</td>";
            
            // Solo mostrar celda de Lectores para doctorado
            if($tabla == "alumnos_doctorado") {
                echo "<td class='grupo-campos' title='".htmlspecialchars($row["lectores"])."'>" . 
                    ($row["lectores"] ? htmlspecialchars($row["lectores"]) : "No aplica") . "</td>";
            }
            
            echo "<td class='grupo-campos' title='".htmlspecialchars($row["comite"])."'>" . 
                ($row["comite"] ? htmlspecialchars($row["comite"]) : "No aplica") . "</td>
                    <td>" . htmlspecialchars($row["Fecha_ingreso"]) . "</td>
                    <td>" . ($row["Fecha_obtencion_grado"] ? htmlspecialchars($row["Fecha_obtencion_grado"]) : "No aplica") . "</td>
                    <td>" . ($row["Fecha_baja"] ? htmlspecialchars($row["Fecha_baja"]) : "No aplica") . "</td>
                    <td>" . ($row["En_tiempo"] ? "Sí" : "No") . "</td>
                    <td>" . ($row["Fuera_tiempo"] ? "Sí" : "No") . "</td>
                  </tr>";
        }

        echo "</table>";
    } else {
        echo "<p>No hay alumnos registrados en esta tabla.</p>";
    }
}

// Mostrar datos de ambas tablas
mostrarAlumnos($conn, "alumnos_maestria");
mostrarAlumnos($conn, "alumnos_doctorado");

// Cerrar conexión
$conn->close();
?>
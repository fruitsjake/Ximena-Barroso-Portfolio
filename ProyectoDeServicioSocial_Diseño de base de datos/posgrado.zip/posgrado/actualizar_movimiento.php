<?php
include 'conexion.php';

// Configuración de subida de archivos
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Recuperar datos del formulario
$no_CVU = intval($_POST['no_CVU']);
$nombre_alumno = !empty($_POST['nombre_alumno']) ? htmlspecialchars($_POST['nombre_alumno']) : null;
$lugar_de_movilidad = !empty($_POST['lugar_de_movilidad']) ? htmlspecialchars($_POST['lugar_de_movilidad']) : null;
$fecha_inicio = !empty($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : null;
$fecha_fin = !empty($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;
$investigación = !empty($_POST['investigación']) ? htmlspecialchars($_POST['investigación']) : null;

// Manejar archivo subido
$archivoNombre = null;

// 1. Obtener archivo actual si existe
$sql_archivo_actual = "SELECT archivo FROM movilidad_academica WHERE no_CVU = ?";
$stmt_archivo = $conn->prepare($sql_archivo_actual);
$stmt_archivo->bind_param("i", $no_CVU);
$stmt_archivo->execute();
$stmt_archivo->bind_result($archivo_actual);
$stmt_archivo->fetch();
$stmt_archivo->close();

// 2. Procesar nuevo archivo
if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
    $archivoTmp = $_FILES['archivo']['tmp_name'];
    $archivoNombre = uniqid() . '_' . basename($_FILES['archivo']['name']);
    $archivoExt = strtolower(pathinfo($archivoNombre, PATHINFO_EXTENSION));

    // Validar tipo de archivo
    $allowed = ['pdf', 'doc', 'docx'];
    if (in_array($archivoExt, $allowed)) {
        move_uploaded_file($archivoTmp, $uploadDir . $archivoNombre);
        // Eliminar archivo antiguo si existe
        if ($archivo_actual && file_exists($uploadDir . $archivo_actual)) {
            unlink($uploadDir . $archivo_actual);
        }
    } else {
        echo "<script>
            alert('Error: Solo se permiten archivos PDF, DOC o DOCX.');
            window.history.back();
        </script>";
        exit();
    }
}

// 3. Construir consulta SQL dinámica
$updates = [];
$params = [];
$types = "";

// Campos a actualizar
if ($nombre_alumno !== null) {
    $updates[] = "nombre_alumno = ?";
    $params[] = $nombre_alumno;
    $types .= "s";
}

if ($lugar_de_movilidad !== null) {
    $updates[] = "lugar_de_movilidad = ?";
    $params[] = $lugar_de_movilidad;
    $types .= "s";
}

if ($fecha_inicio !== null) {
    $updates[] = "fecha_inicio = ?";
    $params[] = $fecha_inicio;
    $types .= "s";
}

if ($fecha_fin !== null) {
    $updates[] = "fecha_fin = ?";
    $params[] = $fecha_fin;
    $types .= "s";
}

if ($investigación !== null) {
    $updates[] = "investigación = ?";
    $params[] = $investigación;
    $types .= "s";
}

// Añadir archivo incluso si otros campos están vacíos
if ($archivoNombre !== null) {
    $updates[] = "archivo = ?";
    $params[] = $archivoNombre;
    $types .= "s";
}

// 4. Ejecutar actualización si hay cambios
if (!empty($updates)) {
    $sql = "UPDATE movilidad_academica SET " . implode(", ", $updates) . " WHERE no_CVU = ?";
    $params[] = $no_CVU;
    $types .= "i";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        $mensaje = "Movimiento actualizado correctamente.";
    } else {
        $mensaje = "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    $mensaje = "Error: No se ingresaron datos para actualizar.";
}

$conn->close();

echo "<script>
    alert('$mensaje');
    window.location.href = 'movilidad.php';
</script>";
?>
<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root"; // Usuario por defecto en XAMPP
$password = ""; // Contraseña por defecto en XAMPP
$dbname = "posgrado";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    // Mensaje de error personalizado
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Opcional: Configurar el conjunto de caracteres a UTF-8
$conn->set_charset("utf8");

// Mensaje de éxito (solo para depuración, eliminar en producción)
// echo "Conexión exitosa a la base de datos.";
?>
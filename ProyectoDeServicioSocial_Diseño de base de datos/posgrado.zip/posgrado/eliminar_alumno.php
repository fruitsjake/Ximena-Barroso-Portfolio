<?php
include 'conexion.php';

// Recibir datos
$programa = $_POST['programa'];
$no_CVU = intval($_POST['no_CVU']);

// Verificar existencia de CVU
$tabla = ($programa == "maestria") ? "alumnos_maestria" : "alumnos_doctorado";
$sql_check = "SELECT no_CVU FROM $tabla WHERE no_CVU = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $no_CVU);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows == 0) {
    echo "<script>
        alert('Error: El número CVU $no_CVU no existe');
        window.history.back();
    </script>";
    exit();
}
$stmt_check->close();

// Eliminar registro
$sql = "DELETE FROM $tabla WHERE no_CVU = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $no_CVU);

if ($stmt->execute()) {
    $mensaje = "Alumno eliminado exitosamente!";
} else {
    $mensaje = "Error al eliminar: " . $stmt->error;
}

$stmt->close();
$conn->close();

echo "<script>
    alert('$mensaje');
    window.location.href = 'index.php';
</script>";
?>
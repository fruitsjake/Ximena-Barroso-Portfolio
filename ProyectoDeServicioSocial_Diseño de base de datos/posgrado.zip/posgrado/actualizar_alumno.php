<?php
include 'conexion.php';

// Configurar MySQLi para lanzar excepciones
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // 1. Validar datos básicos
    $programa = $_POST['programa'] ?? '';
    $no_CVU = intval($_POST['no_CVU'] ?? 0);

    if (!in_array($programa, ['maestria', 'doctorado'])) {
        throw new Exception("Programa no válido");
    }

    // 2. Recoger TODOS los campos (opcionales)
    $campos = [
        'Fecha_obtencion_grado' => !empty($_POST['Fecha_obtencion_grado']) ? $_POST['Fecha_obtencion_grado'] : null,
        'fecha_baja' => !empty($_POST['fecha_baja']) ? $_POST['fecha_baja'] : null,
        'primer_director_tesis' => !empty($_POST['primer_director_tesis']) ? $_POST['primer_director_tesis'] : null,
        'segundo_director_tesis' => !empty($_POST['segundo_director_tesis']) ? $_POST['segundo_director_tesis'] : null,
        'presidente' => !empty($_POST['presidente']) ? $_POST['presidente'] : null,
        'secretario' => !empty($_POST['secretario']) ? $_POST['secretario'] : null,
        'primer_vocal' => !empty($_POST['primer_vocal']) ? $_POST['primer_vocal'] : null,
        'segundo_vocal' => !empty($_POST['segundo_vocal']) ? $_POST['segundo_vocal'] : null,
        'tercer_vocal' => !empty($_POST['tercer_vocal']) ? $_POST['tercer_vocal'] : null,
        'primer_lector_critico' => !empty($_POST['primer_lector_critico']) ? $_POST['primer_lector_critico'] : null,
        'segundo_lector_critico' => !empty($_POST['segundo_lector_critico']) ? $_POST['segundo_lector_critico'] : null
    ];

    // 3. Campos adicionales solo para doctorado
    if ($programa == 'doctorado') {
        $campos['tercer_lector_critico'] = !empty($_POST['tercer_lector_critico']) ? $_POST['tercer_lector_critico'] : null;
        $campos['cuarto_lector_critico'] = !empty($_POST['cuarto_lector_critico']) ? $_POST['cuarto_lector_critico'] : null;
    }

    // 4. Validar formato de fechas (solo si no están vacías)
    foreach (['Fecha_obtencion_grado', 'fecha_baja'] as $campo) {
        if ($campos[$campo] && !DateTime::createFromFormat('Y-m-d', $campos[$campo])) {
            throw new Exception("Formato de fecha inválido en $campo");
        }
    }

    // 5. Verificar existencia del alumno (versión segura)
    $tabla = ($programa == "maestria") ? "alumnos_maestria" : "alumnos_doctorado";
    
    $stmt_check = $conn->prepare("SELECT Fecha_ingreso FROM $tabla WHERE no_CVU = ?");
    $stmt_check->bind_param("i", $no_CVU);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows === 0) {
        throw new Exception("El alumno con CVU $no_CVU no existe");
    }

    $stmt_check->bind_result($fecha_ingreso);
    $stmt_check->fetch();
    $stmt_check->close();

    // 6. Calcular tiempos de graduación (si hay fecha de obtención)
    $anios_estipulados = ($programa == 'doctorado' && date('Y', strtotime($fecha_ingreso)) <= 2022) ? 5 : 3;
    $tiempos = ['en_tiempo' => null, 'fuera_tiempo' => null];

    if ($campos['Fecha_obtencion_grado']) {
        $diferencia = (strtotime($campos['Fecha_obtencion_grado']) - strtotime($fecha_ingreso)) / 31536000; // segundos en un año
        $tiempo_real = round($diferencia, 2);
        
        $tiempos = [
            'en_tiempo' => $tiempo_real <= $anios_estipulados ? $tiempo_real : null,
            'fuera_tiempo' => $tiempo_real > $anios_estipulados ? $tiempo_real : null
        ];
    }

    // 7. Construir consulta SQL dinámica
    $sql = "UPDATE $tabla SET 
            Fecha_obtencion_grado = ?, 
            fecha_baja = ?, 
            En_tiempo = ?, 
            Fuera_tiempo = ?, ";

    // Agregar campos dinámicos (todos opcionales)
    foreach (array_keys($campos) as $campo) {
        if (!in_array($campo, ['Fecha_obtencion_grado', 'fecha_baja'])) {
            $sql .= "$campo = ?, ";
        }
    }

    $sql = rtrim($sql, ', ') . " WHERE no_CVU = ?";

    // 8. Preparar parámetros
    $tipos = 'ssdd'; // Para las fechas y tiempos
    $valores = [
        $campos['Fecha_obtencion_grado'],
        $campos['fecha_baja'],
        $tiempos['en_tiempo'],
        $tiempos['fuera_tiempo']
    ];

    // Agregar campos dinámicos
    foreach ($campos as $key => $value) {
        if (!in_array($key, ['Fecha_obtencion_grado', 'fecha_baja'])) {
            $tipos .= 's';
            $valores[] = $value;
        }
    }

    $valores[] = $no_CVU; // Para el WHERE
    $tipos .= 'i';

    // 9. Ejecutar actualización
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);
    $stmt->execute();
    $stmt->close();

    // 10. Éxito
    echo "<script>
        alert('¡Datos actualizados correctamente!');
        window.location.href = 'index.php';
    </script>";

} catch (Exception $e) {
    // Error
    echo "<script>
        alert('Error: " . addslashes($e->getMessage()) . "');
        window.history.back();
    </script>";
} finally {
    if (isset($conn)) $conn->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movilidad Académica</title>
    <style>
        /* Estilos para el header y el navbar */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        } 
        h1 {
            text-align: center;
            color: #333;
        }
        header {
            background-color: #007BFF;
            padding: 10px 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .navbar {
            display: flex;
            gap: 20px;
        }
        .navbar a {
            color: #007BFF;
            text-decoration: none;
            font-size: 20px;
            transition: color 0.3s;
            background-color: white;
            padding: 10px;
            border-radius: 10px
        }
        .navbar a:hover {
            color: #f8f9fa;
            background-color:rgb(80, 164, 255);
        }

        /* Estilos para las secciones y formularios */
        .menu {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .menu button {
            padding: 10px 20px;
            border: none;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .menu button:hover {
            background-color: #0056b3;
        }

        .seccion-acciones {
            display: none;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .seccion-acciones.activa {
            display: block;
        }

        .contenedor {
            width: 70%;
            margin-left: 15%;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        label {
            color: #666;
            font-size: 0.9em;
        }

        input, select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f8f8f8;
            color: #333;
        }

        tr:hover {
            background-color: #f9f9f9;
        }
        
        /* Estilos para el formulario de PDF */
        .formulario-pdf {
            background-color: #e8f4f8;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .formulario-pdf h2 {
            margin-top: 0;
            color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Header con Navbar -->
    <header>
        <h1>Movilidad Académica</h1>
        <nav class="navbar">
            <a href="index.php">Gestión de Alumnos</a>
            <a href="movilidad.php">Movilidad Académica</a>
        </nav>
    </header>

    <h1>Movilidad Académica</h1>

    <!-- Menú de Pestañas -->
    <div class="menu">
        <button onclick="mostrarSeccion('agregar')">Agregar Movimiento</button>
        <button onclick="mostrarSeccion('actualizar')">Actualizar Movimiento</button>
        <button onclick="mostrarSeccion('eliminar')">Eliminar Movimiento</button>
    </div>

    <div class="contenedor">
        <!-- Sección de Agregar Movimiento -->
        <div id="agregar" class="seccion-acciones activa">
            <h2>Agregar Movimiento</h2>
            <form action="guardar_movimiento.php" method="post">
                <label for="no_CVU">No. CVU:</label>
                <input type="number" id="no_CVU" name="no_CVU" required>
                <label for="nombre_alumno">Nombre del Alumno:</label>
                <input type="text" id="nombre_alumno" name="nombre_alumno" required>
                <label for="lugar_de_movilidad">Lugar de Movilidad:</label>
                <input type="text" id="lugar_de_movilidad" name="lugar_de_movilidad" required>
                <label for="fecha_inicio">Fecha de Inicio:</label>
                <input type="date" id="fecha_inicio" name="fecha_inicio" required>
                <label for="fecha_fin">Fecha de Fin:</label>
                <input type="date" id="fecha_fin" name="fecha_fin">
                <label for="investigación">Investigación:</label>
                <input type="text" id="investigación" name="investigación" required>
                <input type="submit" value="Agregar Movimiento">
            </form>
        </div>

        <!-- Sección de Actualizar Movimiento -->
        <div id="actualizar" class="seccion-acciones">
            <h2>Actualizar Movimiento</h2>
            <form action="actualizar_movimiento.php" method="post" enctype="multipart/form-data">
                <label for="no_CVU_actualizar">No. CVU:</label>
                <input type="number" id="no_CVU_actualizar" name="no_CVU" required>

                <label for="nombre_alumno_actualizar">Nombre del Alumno:</label>
                <input type="text" id="nombre_alumno_actualizar" name="nombre_alumno">

                <label for="lugar_de_movilidad_actualizar">Lugar de Movilidad:</label>
                <input type="text" id="lugar_de_movilidad_actualizar" name="lugar_de_movilidad">

                <label for="fecha_inicio_actualizar">Fecha de Inicio:</label>
                <input type="date" id="fecha_inicio_actualizar" name="fecha_inicio">

                <label for="fecha_fin_actualizar">Fecha de Fin:</label>
                <input type="date" id="fecha_fin_actualizar" name="fecha_fin">

                <label for="investigación_actualizar">Investigación:</label>
                <input type="text" id="investigación_actualizar" name="investigación">

                <label for="archivo">Subir archivo:</label>
                <input type="file" id="archivo" name="archivo" accept=".pdf,.doc,.docx">

                <input type="submit" value="Actualizar Movimiento">
            </form>
        </div>

        <!-- Sección de Eliminar Movimiento -->
        <div id="eliminar" class="seccion-acciones">
            <h2>Eliminar Movimiento</h2>
            <form action="eliminar_movimiento.php" method="post">
                <label for="no_CVU_eliminar">No. CVU:</label>
                <input type="number" id="no_CVU_eliminar" name="no_CVU" required>
                <input type="submit" value="Eliminar Movimiento">
            </form>
        </div>

        <!-- Tabla de Movimientos -->
        <div class="seccion-fija">
            <h2>Movimientos Académicos</h2>
            <table>
                <thead>
                    <tr>
                        <th>No. CVU</th>
                        <th>Nombre</th>
                        <th>Lugar</th>
                        <th>Fecha Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Investigación</th>
                        <th>Archivo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'conexion.php';
                    $sql = "SELECT * FROM movilidad_academica";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['no_CVU']}</td>
                                <td>{$row['nombre_alumno']}</td>
                                <td>{$row['lugar_de_movilidad']}</td>
                                <td>{$row['fecha_inicio']}</td>
                                <td>{$row['fecha_fin']}</td>
                                <td>{$row['investigación']}</td>
                                <td>";
                            if ($row['archivo']) {
                                echo "<a href='uploads/{$row['archivo']}' target='_blank'>Descargar</a>";
                            } else {
                                echo "N/A";
                            }
                            echo "</td></tr>";
                        }
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Nuevo formulario para generar PDF (modificado para usar años) -->
        <div class="seccion-fija formulario-pdf">
            <h2>Generar Reporte de Movilidad</h2>
            <form action="generar_pdf_movilidad.php" method="post">
                <label for="anio_inicio">Año Inicio (Obligatorio):</label>
                <input type="number" id="anio_inicio" name="anio_inicio" min="2000" max="2099" required>

                <label for="anio_fin">Año Fin (Opcional):</label>
                <input type="number" id="anio_fin" name="anio_fin" min="2000" max="2099">

                <input type="submit" value="Generar PDF">
            </form>
        </div>
    </div>

    <!-- JavaScript para Mostrar/Ocultar Secciones -->
    <script>
        function mostrarSeccion(seccionId) {
            // Ocultar todas las secciones de acciones
            document.querySelectorAll('.seccion-acciones').forEach(seccion => {
                seccion.classList.remove('activa');
            });

            // Mostrar la sección seleccionada
            document.getElementById(seccionId).classList.add('activa');
        }
    </script>
</body>
</html>
<?php
require_once('tcpdf/tcpdf.php');
include 'conexion.php';

// Recoger parámetros del formulario (años)
$anio_inicio = $_POST['anio_inicio'];
$anio_fin = !empty($_POST['anio_fin']) ? $_POST['anio_fin'] : date('Y');

// Convertir años en fechas (1 de enero del año inicio a 31 de diciembre del año fin)
$fecha_inicio = $anio_inicio . '-01-01';
$fecha_fin = $anio_fin . '-12-31';

// Consulta para obtener movimientos en el rango de años
$sql = "SELECT * FROM movilidad_academica 
        WHERE YEAR(fecha_inicio) >= ? AND (YEAR(fecha_fin) <= ? OR fecha_fin IS NULL)
        ORDER BY fecha_inicio";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $anio_inicio, $anio_fin);
$stmt->execute();
$result = $stmt->get_result();

// Preparar datos para gráfica
$movimientos_por_anio = array();

// Crear PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Sistema de Movilidad');
$pdf->SetAuthor('Tu Nombre');
$pdf->SetTitle('Reporte de Movilidad');
$pdf->SetSubject('Movilidad Académica');

// Configurar márgenes
$pdf->SetMargins(15, 25, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(15);

// Agregar página
$pdf->AddPage();

// Título
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 15, 'Reporte de Movilidad Académica', 0, 1, 'C');
$pdf->Ln(8);

// Información del reporte
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(0, 10, 'Año Inicio: ' . $anio_inicio, 0, 1);
$pdf->Cell(0, 10, 'Año Fin: ' . $anio_fin, 0, 1);
$pdf->Ln(12);

// Tabla de movimientos
$pdf->SetFont('helvetica', 'B', 12);
$pdf->SetFillColor(240, 240, 240);
$pdf->Cell(25, 10, 'CVU', 1, 0, 'C', 1);
$pdf->Cell(40, 10, 'Nombre', 1, 0, 'C', 1);
$pdf->Cell(40, 10, 'Lugar', 1, 0, 'C', 1);
$pdf->Cell(25, 10, 'Inicio', 1, 0, 'C', 1);
$pdf->Cell(25, 10, 'Fin', 1, 0, 'C', 1);
$pdf->Cell(40, 10, 'Investigación', 1, 1, 'C', 1);

$pdf->SetFont('helvetica', '', 10);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(25, 10, $row['no_CVU'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['nombre_alumno'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['lugar_de_movilidad'], 1, 0, 'C');
    $pdf->Cell(25, 10, $row['fecha_inicio'], 1, 0, 'C');
    $pdf->Cell(25, 10, $row['fecha_fin'] ?? 'N/A', 1, 0, 'C');
    $pdf->Cell(40, 10, $row['investigación'], 1, 1, 'C');
    
    // Datos para gráfica (por año de inicio)
    $anio = date('Y', strtotime($row['fecha_inicio']));
    $movimientos_por_anio[$anio] = ($movimientos_por_anio[$anio] ?? 0) + 1;
}

// Espacio para gráfica
$pdf->Ln(20);

// Gráfica de movimientos por año
if (!empty($movimientos_por_anio)) {
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Movimientos por Año', 0, 1, 'C');
    $pdf->Ln(8);
    
    ksort($movimientos_por_anio);
    $anios = array_keys($movimientos_por_anio);
    $cantidades = array_values($movimientos_por_anio);
    $max_cantidad = max($cantidades);
    
    $ancho_barra = 160 / count($anios);
    $x = 25;
    $y_start = $pdf->GetY() + 10;
    $altura_max = 50;
    
    // Ejes
    $pdf->Line(20, $y_start, 20, $y_start - $altura_max);
    $pdf->Line(20, $y_start, 190, $y_start);
    
    // Etiquetas eje Y
    for ($i = 0; $i <= $max_cantidad; $i++) {
        $y = $y_start - ($i / $max_cantidad * $altura_max);
        $pdf->Line(18, $y, 20, $y);
        $pdf->Text(10, $y - 2, $i);
    }
    
    // Barras
    $pdf->SetFillColor(54, 162, 235);
    foreach ($movimientos_por_anio as $anio => $cantidad) {
        $altura_barra = ($cantidad / $max_cantidad) * $altura_max;
        $pdf->Rect($x, $y_start - $altura_barra, $ancho_barra - 5, $altura_barra, 'F');
        
        // Etiquetas
        $pdf->Text($x + ($ancho_barra/2) - 5, $y_start + 5, $anio);
        $pdf->Text($x + ($ancho_barra/2) - 5, $y_start - $altura_barra - 5, $cantidad);
        
        $x += $ancho_barra;
    }
}

// Salida del PDF
$pdf->Output('reporte_movilidad.pdf', 'D');

$stmt->close();
$conn->close();
?>